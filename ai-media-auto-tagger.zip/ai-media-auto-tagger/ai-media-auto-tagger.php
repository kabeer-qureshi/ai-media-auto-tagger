<?php
/**
 * Plugin Name: AI Media Auto-Tagger
 * Plugin URI:  https://github.com/kabeer-qureshi/ai-media-auto-tagger/
 * Description: Automatically generate SEO-optimized Alt Text, Titles, and Descriptions for uploaded images using Google Gemini 2.0 AI.
 * Version:     1.0.0
 * Author:      Abdul Kabeer
 * Author URI:  https://www.linkedin.com/in/abdul-kabeer-b959682b4/
 * Text Domain: ai-media-auto-tagger
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct access is not allowed.' );
}

define( 'AIMAT_VERSION', '1.0.0' );
define( 'AIMAT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AIMAT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'AIMAT_BASENAME', plugin_basename( __FILE__ ) );

class AI_Media_Auto_Tagger {
    public function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }

    private function load_dependencies() {
        require_once AIMAT_PLUGIN_DIR . 'includes/class-aimat-settings.php';
        require_once AIMAT_PLUGIN_DIR . 'includes/class-aimat-api.php';
        require_once AIMAT_PLUGIN_DIR . 'includes/class-aimat-core.php';
    }

    private function init_hooks() {
        add_action( 'plugins_loaded', array( $this, 'init_plugin_classes' ) );
    }

    public function init_plugin_classes() {
        new AIMAT_Settings();
        new AIMAT_Core();
    }
}
new AI_Media_Auto_Tagger();