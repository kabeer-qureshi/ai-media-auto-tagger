jQuery(document).ready(function($) {
    
    // Initialize Select2 UI Dropdown
    $('.aimat-select2').select2({ minimumResultsForSearch: Infinity, width: '160px' });

    // Handle Filter Apply Action
    $('#aimat-apply-filter').on('click', function(e) {
        e.preventDefault();
        var status = $('#aimat-status-filter').val();
        var url = new URL(window.location.href);
        url.searchParams.set('aimat_status', status);
        url.searchParams.set('paged', 1);
        window.location.href = url.toString();
    });

    // Custom Modal Dialog Handler
    function showModal(title, text, showConfirm, callback) {
        $('#aimat-modal-title').text(title);
        $('#aimat-modal-text').text(text);
        
        $('#aimat-modal-cancel').off('click').on('click', function() {
            $('#aimat-modal').removeClass('show');
        });

        if(showConfirm) {
            $('#aimat-modal-confirm').show().off('click').on('click', function() {
                $('#aimat-modal').removeClass('show');
                if(callback) callback();
            });
            $('#aimat-modal-cancel').text('Cancel');
        } else {
            $('#aimat-modal-confirm').hide();
            $('#aimat-modal-cancel').text('Close');
        }
        
        $('#aimat-modal').addClass('show');
    }

    // Auto-Tag Bulk Process Trigger
    $('#aimat-auto-tag-btn').on('click', function(e) {
        e.preventDefault();
        var btn = $(this);
        var originalText = btn.html();

        showModal('Start Bulk Auto-Tagging?', 'This will process all pending images and retry recoverable errors (like API Limits or Timeouts). Permanent errors (Large Size, Unsupported Format) will be intentionally skipped. Proceed?', true, function() {
            btn.html('<span class="dashicons dashicons-update aimat-spin"></span> Processing...').prop('disabled', true);

            $.post(aimat_ajax.url, { action: 'aimat_get_pending', nonce: aimat_ajax.nonce }, function(res) {
                if(res.success && res.data.length > 0) {
                    processImageQueue(res.data, btn, originalText);
                } else {
                    // Notification if no recoverable images are left
                    showModal('Library Optimized! 🎉', 'There are no pending or recoverable images left to process. (Images with permanent format or size errors are safely ignored).', false);
                    btn.html(originalText).prop('disabled', false);
                }
            });
        });
    });

    // Queue Processor (Processes images sequentially to prevent server crash)
    function processImageQueue(ids, btn, originalText) {
        var total = ids.length;
        var current = 0;

        function processNext() {
            if(current >= total) {
                btn.html('Done! Reloading...');
                setTimeout(function() { location.reload(); }, 1000);
                return;
            }
            btn.html('<span class="dashicons dashicons-update aimat-spin"></span> Tagging ' + (current+1) + ' of ' + total);

            $.post(aimat_ajax.url, { action: 'aimat_process_image', image_id: ids[current], nonce: aimat_ajax.nonce }, function() {
                current++;
                processNext(); 
            }).fail(function() { 
                current++; 
                processNext(); 
            });
        }
        processNext();
    }

    // Single Image Regenerate Trigger
    $('.aimat-regenerate-btn').on('click', function(e) {
        e.preventDefault();
        var btn = $(this);
        var id = btn.data('id');
        var icon = btn.find('.dashicons');
        
        icon.removeClass('dashicons-image-rotate').addClass('dashicons-update aimat-spin');
        btn.prop('disabled', true);

        $.post(aimat_ajax.url, { action: 'aimat_process_image', image_id: id, nonce: aimat_ajax.nonce }, function() {
            location.reload();
        });
    });

});