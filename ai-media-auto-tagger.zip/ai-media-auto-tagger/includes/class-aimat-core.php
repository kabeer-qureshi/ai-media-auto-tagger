<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class AIMAT_Core {

    public function __construct() {
        add_action( 'add_attachment', array( $this, 'process_new_attachment' ) );
        add_action( 'wp_ajax_aimat_get_pending', array( $this, 'ajax_get_pending' ) );
        add_action( 'wp_ajax_aimat_process_image', array( $this, 'ajax_process_image' ) );
    }

    public function ajax_get_pending() {
        check_ajax_referer( 'aimat_ajax_nonce', 'nonce' );
        
        // Security Check: Ensure only authorized users can process images
        if ( ! current_user_can( 'upload_files' ) ) {
            wp_send_json_error( 'Unauthorized Access' );
        }

        $args = array( 
            'post_type'      => 'attachment', 
            'post_status'    => 'inherit', 
            'post_mime_type' => 'image', 
            'posts_per_page' => -1, 
            'meta_query'     => array( 
                'relation' => 'OR', 
                array( 'key' => '_wp_attachment_image_alt', 'compare' => 'NOT EXISTS' ), 
                array( 'key' => '_wp_attachment_image_alt', 'value' => '', 'compare' => '=' ) 
            ) 
        );
        $query = new WP_Query( $args );
        
        $valid_ids = array();
        
        foreach ( $query->posts as $post ) {
            $content = $post->post_content;
            
            // Allow strictly pending images without any previous errors
            if ( strpos( $content, 'AI Error' ) === false ) {
                $valid_ids[] = $post->ID;
            } 
            // Allow only recoverable errors (Limits/Timeout) for bulk retry
            elseif ( strpos( $content, 'Limits Reached' ) !== false || strpos( $content, 'Timeout' ) !== false ) {
                $valid_ids[] = $post->ID;
            }
        }

        wp_send_json_success( $valid_ids );
    }

   public function ajax_process_image() {
        check_ajax_referer( 'aimat_ajax_nonce', 'nonce' );
        
        // Security Check
        if ( ! current_user_can( 'upload_files' ) ) {
            wp_send_json_error( 'Unauthorized Access' );
        }

        $image_id = isset( $_POST['image_id'] ) ? intval( $_POST['image_id'] ) : 0;
        
        if ( $image_id ) { 
            $this->process_new_attachment( $image_id ); 
            wp_send_json_success(); 
        }
        wp_send_json_error();
    }

    public function process_new_attachment( $attachment_id ) {
        if ( ! wp_attachment_is_image( $attachment_id ) ) return;
        
        $api = new AIMAT_API();
        if ( ! $api->is_configured() ) return;

        $options = get_option( 'aimat_settings' );
        $prompt = !empty( $options['custom_prompt'] ) ? $options['custom_prompt'] : "Act as an expert SEO copywriter. Analyze this image and write a highly descriptive, keyword-rich alt text in a single short sentence (maximum 15 words).";
        
        $file_path = get_attached_file( $attachment_id );
        if ( ! $file_path ) return;

        $ai_generated_text = $api->generate_image_meta( $file_path, $prompt );

        // Handle exact API errors
        if ( strpos( $ai_generated_text, 'API_ERROR|' ) === 0 ) {
            $exact_error = str_replace('API_ERROR|', '', $ai_generated_text);
            $attachment_data = array(
                'ID'           => $attachment_id,
                'post_content' => 'AI Error: ' . sanitize_text_field( $exact_error ),
            );

            // Temporarily remove hook to avoid infinite loop during update
            remove_action( 'add_attachment', array( $this, 'process_new_attachment' ) );
            wp_update_post( $attachment_data );
            add_action( 'add_attachment', array( $this, 'process_new_attachment' ) );
            return;
        } elseif ( $ai_generated_text ) {
            // Success: Update SEO Meta and Rename Physical File
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', $ai_generated_text );
            $ai_title = wp_trim_words( $ai_generated_text, 5, '' );
            $new_slug = sanitize_title( $ai_title );
            
            $attachment_data = array(
                'ID'           => $attachment_id,
                'post_title'   => $ai_title,
                'post_name'    => $new_slug,
                'post_excerpt' => $ai_generated_text,
                'post_content' => $ai_generated_text,
            );

            remove_action( 'add_attachment', array( $this, 'process_new_attachment' ) );
            wp_update_post( $attachment_data );
            $this->rename_physical_file( $attachment_id, $new_slug );
            add_action( 'add_attachment', array( $this, 'process_new_attachment' ) );
            return; 
        } else {
            // Fallback for unknown connection issues
            $attachment_data = array(
                'ID'           => $attachment_id,
                'post_content' => 'AI Error: Unknown connection issue.',
            );
            remove_action( 'add_attachment', array( $this, 'process_new_attachment' ) );
            wp_update_post( $attachment_data );
            add_action( 'add_attachment', array( $this, 'process_new_attachment' ) );
        }
    }

    private function rename_physical_file( $attachment_id, $new_slug ) {
        $file_path = get_attached_file( $attachment_id );
        if ( ! $file_path || ! file_exists( $file_path ) ) return;
        
        $info = pathinfo( $file_path );
        $ext  = isset( $info['extension'] ) ? $info['extension'] : '';
        if ( ! $ext ) return;

        $new_file_name = wp_unique_filename( $info['dirname'], $new_slug . '.' . $ext );
        $new_file_path = $info['dirname'] . '/' . $new_file_name;

        // Perform renaming of physical file and its thumbnails
        if ( rename( $file_path, $new_file_path ) ) {
            update_attached_file( $attachment_id, $new_file_path );
            $meta = wp_get_attachment_metadata( $attachment_id );
            
            if ( is_array( $meta ) && ! empty( $meta['file'] ) ) {
                $meta['file'] = dirname( $meta['file'] ) . '/' . $new_file_name;
                
                if ( isset( $meta['sizes'] ) && is_array( $meta['sizes'] ) ) {
                    foreach ( $meta['sizes'] as $size => $size_info ) {
                        $old_thumb_path = $info['dirname'] . '/' . $size_info['file'];
                        $thumb_ext = pathinfo( $size_info['file'], PATHINFO_EXTENSION );
                        $thumb_new_name = $new_slug . '-' . $size_info['width'] . 'x' . $size_info['height'] . '.' . $thumb_ext;
                        $new_thumb_path = $info['dirname'] . '/' . $thumb_new_name;

                        if ( file_exists( $old_thumb_path ) ) {
                            rename( $old_thumb_path, $new_thumb_path );
                            $meta['sizes'][$size]['file'] = $thumb_new_name;
                        }
                    }
                }
                wp_update_attachment_metadata( $attachment_id, $meta );
            }
        }
    }
}