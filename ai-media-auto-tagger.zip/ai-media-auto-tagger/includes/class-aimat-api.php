<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class AIMAT_API {

    private $api_key;

    public function __construct() {
        $options = get_option( 'aimat_settings' );
        $this->api_key = isset( $options['api_key'] ) ? $options['api_key'] : '';
    }

    public function is_configured() {
        return ! empty( $this->api_key );
    }

    /**
     * Helper function to translate raw Google API errors into user-friendly professional messages.
     */
    private function get_professional_error( $raw_error ) {
        $error_lower = strtolower( $raw_error );
        
        // 1. Quota & Limits Error
        if ( strpos( $error_lower, 'quota' ) !== false || strpos( $error_lower, '429' ) !== false || strpos( $error_lower, 'exhausted' ) !== false ) {
            return 'API Limits Reached: Your current AI plan or free quota has been exhausted.';
        } 
        // 2. Safety & Privacy Policy Error
        elseif ( strpos( $error_lower, 'safety' ) !== false || strpos( $error_lower, 'policy' ) !== false || strpos( $error_lower, 'block' ) !== false ) {
            return 'Content Blocked: The AI rejected this image due to strict safety, privacy, or content guidelines.';
        } 
        // 3. File Size Error
        elseif ( strpos( $error_lower, 'size' ) !== false || strpos( $error_lower, 'payload' ) !== false || strpos( $error_lower, 'large' ) !== false ) {
            return 'File Too Large: The image exceeds the maximum size limit for AI processing. Please compress it.';
        } 
        // 4. Unsupported Format Error
        elseif ( strpos( $error_lower, 'mime' ) !== false || strpos( $error_lower, 'format' ) !== false || strpos( $error_lower, 'supported' ) !== false || strpos( $error_lower, 'decode' ) !== false ) {
            return 'Unsupported Format: The AI cannot read this specific image format or encoding.';
        } 
        // 5. Timeout Error
        elseif ( strpos( $error_lower, 'timeout' ) !== false ) {
            return 'Timeout Error: The AI server took too long to respond. Please try regenerating.';
        }
        
        // Fallback for unknown errors
        return 'Connection Failed: ' . wp_trim_words( $raw_error, 10, '...' );
    }

    public function generate_image_meta( $image_path, $prompt ) {
        if ( ! $this->is_configured() || ! file_exists( $image_path ) ) return false;

        $default_models = array( 'gemini-3-flash', 'gemini-2.5-flash', 'gemini-robotics-er-1.5-preview', 'gemma-3-27b', 'gemma-3-12b', 'gemini-2.0-flash' );
        $models_to_try = get_option( 'aimat_valid_models', $default_models );
        
        // Prioritize the last known working model to save API calls
        $working_model = get_option( 'aimat_working_model', '' );
        if ( $working_model && in_array( $working_model, $models_to_try ) ) {
            $models_to_try = array_diff( $models_to_try, array( $working_model ) );
            array_unshift( $models_to_try, $working_model );
        }

        // Performance Check: Prevent processing files over 10MB to avoid server timeouts
        $file_size = filesize($image_path);
        if( $file_size > 10 * 1024 * 1024 ) { 
            return 'API_ERROR|File Too Large: The image is over 10MB. Please compress it before auto-tagging.';
        }

        $image_data = file_get_contents( $image_path );
        $base64_image = base64_encode( $image_data );
        $mime_type = mime_content_type( $image_path );

        $body_json = wp_json_encode( array(
            'contents' => array(
                array(
                    'parts' => array(
                        array( 'text' => $prompt ),
                        array( 'inline_data' => array( 'mime_type' => $mime_type, 'data' => $base64_image ) )
                    )
                )
            )
        ) );

        $professional_error = '';

        foreach ( $models_to_try as $model_id ) {
            $request_url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model_id . ':generateContent?key=' . $this->api_key;
            
            $args = array(
                'method'  => 'POST',
                'timeout' => 20,
                'headers' => array( 'Content-Type'  => 'application/json' ),
                'body'    => $body_json,
            );

            $response = wp_remote_post( $request_url, $args );

            if ( is_wp_error( $response ) ) {
                $raw_error = $response->get_error_message();
                $professional_error = $this->get_professional_error( $raw_error );
            } else {
                $response_code = wp_remote_retrieve_response_code( $response );
                $body_raw = wp_remote_retrieve_body( $response );
                $data = json_decode( $body_raw, true );

                if ( $response_code === 200 ) {
                    // Success response validation
                    if ( isset( $data['candidates'][0]['content']['parts'][0]['text'] ) ) {
                        update_option( 'aimat_working_model', $model_id );
                        return sanitize_text_field( trim( $data['candidates'][0]['content']['parts'][0]['text'] ) );
                    } 
                    // Handle Google's soft-blocks (200 OK but content blocked)
                    elseif ( isset( $data['promptFeedback']['blockReason'] ) || isset( $data['candidates'][0]['finishReason'] ) ) {
                        $professional_error = $this->get_professional_error( 'safety block policy' );
                    } else {
                        $professional_error = $this->get_professional_error( 'unsupported format decode' );
                    }
                } else {
                    $raw_error = isset( $data['error']['message'] ) ? $data['error']['message'] : 'HTTP ' . $response_code;
                    $professional_error = $this->get_professional_error( $raw_error );
                }
            }

            // Smart Break Logic: If the error is permanent (Size, Format, Blocked), stop trying other models
            $is_permanent_fault = ( strpos( $professional_error, 'File Too Large' ) !== false || strpos( $professional_error, 'Unsupported Format' ) !== false || strpos( $professional_error, 'Content Blocked' ) !== false );
            
            if ( $is_permanent_fault ) {
                return 'API_ERROR|' . $professional_error;
            }
        }

        // Return the final error if all models fail (usually Limits Reached)
        return 'API_ERROR|' . $professional_error;
    }
}