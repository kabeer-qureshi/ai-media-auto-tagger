<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class AIMAT_Settings {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
    }

    public function add_admin_menu() {
        add_menu_page( 'AI Media Tagger', 'AI Tagger', 'manage_options', 'aimat-settings', array( $this, 'create_admin_page' ), 'dashicons-art', 30 );
    }

    public function register_settings() {
        register_setting( 'aimat_setting_group', 'aimat_settings', array( $this, 'sanitize' ) );
    }

    public function sanitize( $input ) {
        $sanitized = array();
        // Standard WordPress unslash before sanitizing
        if ( isset( $input['api_key'] ) ) $sanitized['api_key'] = sanitize_text_field( wp_unslash( $input['api_key'] ) );
        if ( isset( $input['custom_prompt'] ) ) $sanitized['custom_prompt'] = sanitize_textarea_field( wp_unslash( $input['custom_prompt'] ) );
        
        // Force clear transient cache to ensure a fresh fetch of models
        delete_transient( 'aimat_gemini_models' );
        
        if ( !empty( $sanitized['api_key'] ) ) {
            $url = 'https://generativelanguage.googleapis.com/v1beta/models?key=' . $sanitized['api_key'];
            $response = wp_remote_get( $url, array( 'timeout' => 15 ) );
            
            if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
                add_settings_error( 'aimat_setting_group', 'invalid_api_key', 'Verification Failed! Invalid API Key or Network Issue.', 'error' );
            } else {
                $body = json_decode( wp_remote_retrieve_body( $response ), true );
                $valid_models = array();
                
                if ( isset( $body['models'] ) && is_array( $body['models'] ) ) {
                    foreach ( $body['models'] as $model ) {
                        // Check if model supports content generation natively
                        if ( isset( $model['supportedGenerationMethods'] ) && in_array( 'generateContent', $model['supportedGenerationMethods'] ) ) {
                            $model_id = str_replace( 'models/', '', $model['name'] );
                            $model_id_lower = strtolower( $model_id );
                            
                            $is_valid = false;
                            
                            // Regex check for stable and experimental flash/pro models
                            if ( preg_match('/^gemini-(1\.5|2\.0|2\.5|3\.0|3)-(flash|pro)$/i', $model_id_lower) ) { $is_valid = true; }
                            // Include Gemma capabilities
                            elseif ( strpos( $model_id_lower, 'gemma' ) !== false ) { $is_valid = true; }
                            // Include Robotics vision models
                            elseif ( strpos( $model_id_lower, 'robotics' ) !== false ) { $is_valid = true; }

                            // Strictly exclude audio, tts, and embedding variants
                            $is_not_audio = ( strpos( $model_id_lower, 'tts' ) === false && strpos( $model_id_lower, 'audio' ) === false && strpos( $model_id_lower, 'embedding' ) === false );

                            if ( $is_valid && $is_not_audio ) {
                                $valid_models[] = $model_id;
                            }
                        }
                    }
                }
                
                if ( !empty( $valid_models ) ) {
                    update_option( 'aimat_valid_models', $valid_models ); 
                    add_settings_error( 'aimat_setting_group', 'valid_api_key', 'API Verified! ' . count($valid_models) . ' Vision Models (including Gemma & Robotics) auto-discovered.', 'success' );
                } else {
                    add_settings_error( 'aimat_setting_group', 'no_models', 'No valid vision models found for this API Key.', 'warning' );
                }
            }
        }
        return $sanitized;
    }

    public function enqueue_admin_scripts( $hook ) {
        if ( 'toplevel_page_aimat-settings' !== $hook ) return;
        
        // Properly enqueued local assets for WP standard compliance
        wp_enqueue_style( 'aimat-select2-css', AIMAT_PLUGIN_URL . 'assets/css/select2.min.css', array(), '4.1.0' );
        wp_enqueue_script( 'aimat-select2-js', AIMAT_PLUGIN_URL . 'assets/js/select2.min.js', array('jquery'), '4.1.0', true );
        wp_enqueue_style( 'aimat-admin-style', AIMAT_PLUGIN_URL . 'assets/css/admin-style.css', array(), time() );
        wp_enqueue_script( 'aimat-admin-script', AIMAT_PLUGIN_URL . 'assets/js/admin-script.js', array('jquery', 'aimat-select2-js'), time(), true );
        wp_enqueue_style( 'dashicons' );
        
        wp_localize_script( 'aimat-admin-script', 'aimat_ajax', array( 
            'url'   => admin_url( 'admin-ajax.php' ), 
            'nonce' => wp_create_nonce( 'aimat_ajax_nonce' ) 
        ));
    }

    /**
     * Helper to exclude posts containing "AI Error" from the pending list
     */
    public function filter_pending_where( $where ) {
        global $wpdb;
        $where .= " AND {$wpdb->posts}.post_content NOT LIKE '%AI Error%'";
        return $where;
    }

    public function create_admin_page() {
        $options = get_option( 'aimat_settings' );
        $api_key = isset( $options['api_key'] ) ? $options['api_key'] : '';
        $prompt  = isset( $options['custom_prompt'] ) ? $options['custom_prompt'] : "Act as an expert SEO copywriter. Analyze this image and write a highly descriptive, keyword-rich alt text in a single short sentence (maximum 15 words).";
        
        $status_filter = isset( $_GET['aimat_status'] ) ? sanitize_text_field( wp_unslash( $_GET['aimat_status'] ) ) : 'all';
        $paged = isset( $_GET['paged'] ) ? max( 1, intval( $_GET['paged'] ) ) : 1;
        $valid_models = get_option( 'aimat_valid_models', array() );
        ?>
        <div class="aimat-saas-wrap">
            <div class="aimat-header">
                <img class="aimat-logo" src="<?php echo esc_url( AIMAT_PLUGIN_URL . 'assets/images/ai-media-auto-tagger-logo.png' ); ?>" alt="AI-MAT Logo"><h2>AI Media Auto-Tagger</h2>
            </div>
            <?php settings_errors( 'aimat_setting_group' ); ?>
            <div class="aimat-card">
                <form method="post" action="options.php">
                    <?php settings_fields( 'aimat_setting_group' ); ?>
                    <div class="aimat-form-row">
                        <div class="aimat-input-group">
                            <label>API Key (Google AI Studio)</label>
                            <input type="password" name="aimat_settings[api_key]" value="<?php echo esc_attr( $api_key ); ?>" placeholder="AIzaSy..." />
                            <?php if(!empty($valid_models)): ?>
                            <p style="font-size: 12px; color: #059669; margin-top: 5px;"><strong>Active Fallback Models:</strong> <?php echo esc_html( implode(', ', $valid_models) ); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="aimat-form-row">
                        <div class="aimat-input-group">
                            <label>System Prompt (Instructions)</label>
                            <textarea name="aimat_settings[custom_prompt]" rows="3"><?php echo esc_textarea( $prompt ); ?></textarea>
                        </div>
                    </div>
                    <div class="aimat-form-actions"><button type="submit" class="aimat-btn-primary">Save & Verify API</button></div>
                </form>
            </div>
            <div class="aimat-card aimat-table-card">
                <div class="aimat-table-toolbar">
                    <div class="aimat-table-filters">
                        <select id="aimat-status-filter" class="aimat-select2">
                            <option value="all" <?php selected($status_filter, 'all'); ?>>All Status</option>
                            <option value="pending" <?php selected($status_filter, 'pending'); ?>>Pending</option>
                            <option value="processed" <?php selected($status_filter, 'processed'); ?>>Processed</option>
                            <option value="failed" <?php selected($status_filter, 'failed'); ?>>Failed</option>
                        </select>
                        <button id="aimat-apply-filter" class="aimat-btn-outline" style="margin-left: 10px;">Apply</button>
                    </div>
                    <button id="aimat-auto-tag-btn" class="aimat-btn-secondary"><span class="dashicons dashicons-update"></span> Auto-Tag Pending & Recoverable Failed</button>
                </div>
                <table class="aimat-table">
                    <thead><tr><th>Image</th><th>File Name</th><th>Alt Text / Error</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php
                        $args = array( 'post_type' => 'attachment', 'post_mime_type' => 'image', 'post_status' => 'inherit', 'posts_per_page' => 10, 'paged' => $paged );
                        
                        if ( $status_filter === 'processed' ) {
                            $args['meta_query'] = array( array( 'key' => '_wp_attachment_image_alt', 'value' => '', 'compare' => '!=' ) );
                        } elseif ( $status_filter === 'pending' ) {
                            $args['meta_query'] = array( 'relation' => 'OR', array( 'key' => '_wp_attachment_image_alt', 'compare' => 'NOT EXISTS' ), array( 'key' => '_wp_attachment_image_alt', 'value' => '', 'compare' => '=' ) );
                            // Dynamically add SQL filter to exclude permanently failed images
                            add_filter( 'posts_where', array( $this, 'filter_pending_where' ) );
                        } elseif ( $status_filter === 'failed' ) {
                            $args['s'] = 'AI Error';
                        }

                        $query = new WP_Query( $args );

                        // Remove filter immediately after querying to prevent affecting other WP areas
                        if ( $status_filter === 'pending' ) {
                            remove_filter( 'posts_where', array( $this, 'filter_pending_where' ) );
                        }

                        if ( $query->have_posts() ) :
                            while ( $query->have_posts() ) : $query->the_post();
                                $id = get_the_ID(); 
                                $alt = get_post_meta( $id, '_wp_attachment_image_alt', true ); 
                                $desc = get_the_content(); 
                                $thumb = wp_get_attachment_image( $id, array(40, 40) );
                                
                                if ( strpos( $desc, 'AI Error' ) !== false ) { $stat = 'Failed'; $bg = 'aimat-badge-danger'; $text = wp_trim_words($desc, 8); }
                                elseif ( ! empty( $alt ) ) { $stat = 'Processed'; $bg = 'aimat-badge-success'; $text = wp_trim_words($alt, 10); }
                                else { $stat = 'Pending'; $bg = 'aimat-badge-warning'; $text = 'Awaiting AI...'; }
                                ?>
                                <tr>
                                    <td><div class="aimat-img-thumb"><?php echo $thumb ? $thumb : '<span class="dashicons dashicons-format-image"></span>'; ?></div></td>
                                    <td><strong><?php echo esc_html( wp_basename( get_attached_file( $id ) ) ); ?></strong></td>
                                    <td class="aimat-text-muted"><?php echo esc_html( $text ); ?></td>
                                    <td><span class="aimat-badge <?php echo esc_attr( $bg ); ?>"><?php echo esc_html( $stat ); ?></span></td>
                                    <td><?php echo get_the_date( 'M j' ); ?></td>
                                    <td>
                                        <button class="aimat-action-icon aimat-regenerate-btn" data-id="<?php echo esc_attr($id); ?>" title="Regenerate AI Tags"><span class="dashicons dashicons-image-rotate"></span></button>
                                        <a href="<?php echo esc_url( get_edit_post_link( $id ) ); ?>" target="_blank" class="aimat-action-icon" title="Edit Image"><span class="dashicons dashicons-edit"></span></a>
                                    </td>
                                </tr>
                                <?php
                            endwhile;
                        else : echo '<tr><td colspan="6" style="text-align:center; padding: 30px; color: #6c757d;">No images found.</td></tr>'; endif;
                        ?>
                    </tbody>
                </table>
                <?php if ( $query->max_num_pages > 1 ) { echo '<div class="aimat-pagination">'; echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $paged, 'total' => $query->max_num_pages, 'prev_text' => '&laquo; Prev', 'next_text' => 'Next &raquo;' ) ); echo '</div>'; } wp_reset_postdata(); ?>
            </div>
            
            <div id="aimat-modal" class="aimat-modal-overlay">
                <div class="aimat-modal-box"><h3 id="aimat-modal-title">Confirm</h3><p id="aimat-modal-text">Proceed?</p>
                    <div class="aimat-modal-actions"><button id="aimat-modal-cancel" class="aimat-btn-outline">Cancel</button><button id="aimat-modal-confirm" class="aimat-btn-primary">Yes</button></div>
                </div>
            </div>
        </div>
        <?php
    }
}