<?php
/**
 * Fired when the plugin is uninstalled.
 * This file runs when the user deactivates and deletes the plugin.
 */

// If uninstall is not called from WordPress, then exit (Security check)
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Delete plugin settings and cached data from the database to keep it clean
delete_option( 'aimat_settings' );
delete_option( 'aimat_valid_models' );
delete_option( 'aimat_working_model' );
delete_transient( 'aimat_gemini_models' );